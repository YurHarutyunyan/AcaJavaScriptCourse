function problem6(arr1, arr2) {
  let result = [...arr1[0], ...arr2, ...arr1[1]];
  return result;
}
