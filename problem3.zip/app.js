function problem3(arrOfNums) {
  let resultingArray = new Array(100);
  for (num of arrOfNums) {
    resultingArray[num] = num;
  }
}
